
const express = require("express");
const conexion = require("./db");

const app = express();

app.use(express.json());

// GET: consultar todos los estudiantes
app.get("/estudiantes", async (req, res) => {
    try {
        const resultado = await conexion.query(
            "SELECT * FROM estudiantes ORDER BY id"
        );

        res.json(resultado.rows);

    } catch (error) {
        res.status(500).json({ mensaje: error.message });
    }
});

// POST: registrar un estudiante
app.post("/estudiantes", async (req, res) => {
    try {
        const { nombre, correo } = req.body;

        if (!nombre || !correo) {
            return res.status(400).json({
                mensaje: "Debes enviar nombre y correo"
            });
        }

        const resultado = await conexion.query(
            "INSERT INTO estudiantes (nombre, correo) VALUES ($1, $2) RETURNING *",
            [nombre, correo]
        );

        res.status(201).json({
            mensaje: "Estudiante creado correctamente",
            estudiante: resultado.rows[0]
        });

    } catch (error) {
        res.status(500).json({ mensaje: error.message });
    }
});

// PUT: actualizar un estudiante
app.put("/estudiantes/:id", async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre, correo } = req.body;

        if (!nombre || !correo) {
            return res.status(400).json({
                mensaje: "Debes enviar nombre y correo"
            });
        }

        const resultado = await conexion.query(
            "UPDATE estudiantes SET nombre = $1, correo = $2 WHERE id = $3 RETURNING *",
            [nombre, correo, id]
        );

        if (resultado.rowCount === 0) {
            return res.status(404).json({
                mensaje: "Estudiante no encontrado"
            });
        }

        res.json({
            mensaje: "Estudiante actualizado correctamente",
            estudiante: resultado.rows[0]
        });

    } catch (error) {
        res.status(500).json({ mensaje: error.message });
    }
});

// DELETE: eliminar un estudiante
app.delete("/estudiantes/:id", async (req, res) => {
    try {
        const { id } = req.params;

        const resultado = await conexion.query(
            "DELETE FROM estudiantes WHERE id = $1 RETURNING *",
            [id]
        );

        if (resultado.rowCount === 0) {
            return res.status(404).json({
                mensaje: "Estudiante no encontrado"
            });
        }

        res.json({
            mensaje: "Estudiante eliminado correctamente",
            estudiante: resultado.rows[0]
        });

    } catch (error) {
        res.status(500).json({ mensaje: error.message });
    }
});

// Iniciar servidor
app.listen(3000, () => {
    console.log("Servidor funcionando en http://localhost:3000");
});
