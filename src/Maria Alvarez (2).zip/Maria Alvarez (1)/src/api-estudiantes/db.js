
const { Pool } = require("pg");

const conexion = new Pool({
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: "admin",
    database: "universidad"
});

// Comprobar la conexión
conexion.connect()
    .then(cliente => {
        console.log("Conexión con PostgreSQL exitosa");
        cliente.release();
    })
    .catch(error => {
        console.error("Error al conectar con PostgreSQL:", error.message);
    });

module.exports = conexion;
