const express = require("express");

const app = express();

app.use(express.json());

// Datos de ejemplo
let estudiantes = [
    { id: 1, nombre: "Ana", correo: "ana@gmail.com" },
    { id: 2, nombre: "Carlos", correo: "carlos@gmail.com" }
];

// Metodo GET: consultar estudiantes
app.get("/estudiantes", (req, res) => {
    res.json(estudiantes);
});

// Metodo POST: crear un estudiante
app.post("/estudiantes", (req, res) => {
    const nuevoEstudiante = {
        id: estudiantes.length > 0
            ? Math.max(...estudiantes.map(e => e.id)) + 1
            : 1,
        nombre: req.body.nombre,
        correo: req.body.correo
    };

    if (!nuevoEstudiante.nombre || !nuevoEstudiante.correo) {
        return res.status(400).json({
            mensaje: "Debes enviar nombre y correo"
        });
    }

    estudiantes.push(nuevoEstudiante);

    res.status(201).json({
        mensaje: "Estudiante creado correctamente",
        estudiante: nuevoEstudiante
    });
});

// Metodo PUT: actualizar un estudiante
app.put("/estudiantes/:id", (req, res) => {
    const id = Number(req.params.id);

    const estudiante = estudiantes.find(e => e.id === id);

    if (!estudiante) {
        return res.status(404).json({
            mensaje: "Estudiante no encontrado"
        });
    }

    const { nombre, correo } = req.body;

    if (!nombre || !correo) {
        return res.status(400).json({
            mensaje: "Debes enviar nombre y correo"
        });
    }

    estudiante.nombre = nombre;
    estudiante.correo = correo;

    res.json({
        mensaje: "Estudiante actualizado correctamente",
        estudiante: estudiante
    });
});

// Metodo DELETE: eliminar un estudiante
app.delete("/estudiantes/:id", (req, res) => {
    const id = Number(req.params.id);

    const posicion = estudiantes.findIndex(e => e.id === id);

    if (posicion === -1) {
        return res.status(404).json({
            mensaje: "Estudiante no encontrado"
        });
    }

    const eliminado = estudiantes.splice(posicion, 1);

    res.json({
        mensaje: "Estudiante eliminado correctamente",
        estudiante: eliminado[0]
    });
});

// Iniciar servidor
app.listen(3000, () => {
    console.log("Servidor funcionando en http://localhost:3000");
});